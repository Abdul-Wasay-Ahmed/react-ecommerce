import CategoryContainer from "./components/categories/categoreis-container/categoriesContainer";
const App = () =>{

  return (
   <CategoryContainer/>
  )

}

export default App;
































      {/* {categories.map((category)=>(
<CategoryItems key={category.id} category={category}/>
      ))} 
       */}