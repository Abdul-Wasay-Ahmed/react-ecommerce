import "../../categories/categories.scss"
import CategoryItems from "../categories-item/categoriesItem"
const CategoryContainer = () =>{ 

    const categories = [
        {
          "id":1,
          "title":"Denim"
        },
        {
          "id":2,
          "title":"Shirt"
        },
        {
          "id":3,
          "title":"Pants"
        },
        
        {
          "id":4,
          "title":"Hats"
        },
        
        {
          "id":5,
          "title":"Wallets"
        },
        
        ]
        


    return (

<div className="categories-container">
    
    {categories.map((category)=>(
     
     <CategoryItems key={category.id} category={category}/>
     
    
    ))}
    
    
      
    
        </div>
    

    )

}

export default CategoryContainer 